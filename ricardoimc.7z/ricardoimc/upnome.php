<?php
include 'conecta.php';
$id=$_GET  ['id'];
$nome = $_POST['nome'];
$idade = $_POST['idade'];
$altura = $_POST['altura'];
$peso = $_POST['peso'];
$imc = $_POST['imc'];
$classificacao= $_POST['classificacao'];

function calcular_imc($altura, $peso) {
    $imc = $peso / ($altura*$altura);
    return $imc;
}

$resultado = calcular_imc($altura2, $peso2);
$imc2 = round($resultado, 2);


if($imc2 < 18.5) 
{
    $classificacao = "Abaixo do peso";
} 
elseif ($imc2 >= 18.5 && $imc <= 24.9) 
{
    $classificacao = "Peso Adequado)";
} 
elseif ($imc2 >= 25 && $imc <= 29.9) 
{
    $classificacao = "Sobrepeso";
} 
elseif ($imc2 >= 30 && $imc <= 34.9) 
{
    $classificacao = "Obesidade Grau 1";
} 
elseif ($imc2 >= 35 && $imc <= 39.9)
 {
    $classificacao = "Obesidade Grau 2";
}
 else 
 {
    $classificacao = "Obesidade Extrema";
}

$classificacao= $_POST['classificacao'];



$sql= "UPDATE pessoa SET nome=?, idade=?, altura=?, peso=? WHERE id=?";
$update = $conn-> prepare($sql) or die($conn->error);
if(!$update)
{
    echo "Erro na atualização!".$conn->errno.'-'.$conn->error;
}

$update->bind_param('ssssi', $nome, $idade, $altura, $peso, $id);
$update->execute();
$update->close();
header("Location: index.php");

?>
