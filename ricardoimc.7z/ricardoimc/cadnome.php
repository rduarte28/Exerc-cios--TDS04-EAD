<?php
    include 'conecta.php';
    $nome = $_POST['nome'];
    $idade = $_POST['idade'];
    $altura = $_POST['altura'];
    $peso = $_POST['peso'];
    $peso2 = floatval($peso);
    $altura2 = floatval($altura);

    function calcular_imc($altura, $peso) {
        $imc = $peso / ($altura*$altura);
        return $imc;
    }
    
    $imc = calcular_imc($altura2, $peso2);
    $resultado = round($imc, 2);

   
    if($resultado < 18.5) 
    {
        $classificacao = "Abaixo do peso";
    } 
    elseif ($resultado >= 18.5 && $imc <= 24.9) 
    {
        $classificacao = "Peso Adequado)";
    } 
    elseif ($resultado >= 25 && $imc <= 29.9) 
    {
        $classificacao = "Sobrepeso";
    } 
    elseif ($resultado >= 30 && $imc <= 34.9) 
    {
        $classificacao = "Obesidade Grau 1";
    } 
    elseif ($resultado >= 35 && $imc <= 39.9)
     {
        $classificacao = "Obesidade Grau 2";
    }
     else 
     {
        $classificacao = "Obesidade Extrema";
    }

       

    $query = $conn->query("SELECT * FROM pessoa WHERE nome='$nome' AND idade='$idade'");
    if (mysqli_num_rows($query) > 0) {
        echo "<script language='javascript' type='text/javascript'>
        alert('Nome já existe em nossa base de dados!');
        window.location.href='cadastro.php';
        </script>";
        mysqli_close($conn);
    }
    else {
        $sql = "INSERT INTO pessoa (nome,idade,altura,peso,imc,classificacao) VALUES ('$nome','$idade', '$altura','$peso', '$resultado','$classificacao')";
        if (mysqli_query($conn, $sql)) {
            echo "<script language='javascript' type='text/javascript'>
         alert('Dados gravados com sucesso!');
         window.location.href='index.php';
         </script>";
         }
         
         

    }
    mysqli_close($conn);
?>